import "./seed/seed.js";
